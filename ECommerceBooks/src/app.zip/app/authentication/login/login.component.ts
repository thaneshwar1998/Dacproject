import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Authentication } from '../authentication.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  UserName:string;
  Password:string;
  invalidLogin:boolean;
  constructor(private auth:Authentication,private router:Router) 
  { }

  ngOnInit() {
    
  }

  verifyUserLogin(){
    this.auth.authenticate
    (this.UserName,this.Password).subscribe(
      response => {
        console.log(`auth resp ${response}`);
        this.invalidLogin = false;
        this.router.navigate(['']);
      },
      error => {
        alert("invalid login....");
        this.invalidLogin = true;
      }
    );
  }
  
}
/*
serName: string;
  password: string;
  invalidLogin: boolean;
  constructor(private authService: AuthServiceService, private router: Router
  ) {

  }

  ngOnInit() {
  }
  verifyUserLogin() {
    this.authService.authenticate
    (this.userName, this.password).subscribe(
      response => {
        console.log(`auth resp ${response}`);
        // for (let u of response)
        //   console.log(`User ${u.id} ${u.name}`);
        this.invalidLogin = false;
        this.router.navigate(['']);
      },
      error => {
        alert("invalid login....");
        this.invalidLogin = true;
      }
    );

  }*/