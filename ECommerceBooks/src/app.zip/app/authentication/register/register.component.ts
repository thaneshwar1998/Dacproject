import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Authentication } from '../authentication.service';
import { Customer } from '../customer.module';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  Customer=new Customer();
  constructor(private svc:Authentication,private frombuilder:FormBuilder,
                private router:Router) { }

  ngOnInit(): void {
  }
  AddCustomer()
  {
    //console.log(this.Customer);
    this.svc.AddCustomer(this.Customer).subscribe(
      (Response)=>
      {
      console.log(Response);
      this.router.navigate(['/login']);
      });
  }
}
