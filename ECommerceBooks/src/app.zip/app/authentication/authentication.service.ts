import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer.module';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class Authentication {
  baseURL='http://localhost:60312/api/validate';
  constructor(private http:HttpClient) { }

  AddCustomer(data)
  {
        return this.http.post(this.baseURL,data);
  }
  //authentication function
  authenticate(UserName:string,Password:string)
  {
    return this.http.post<any>(this.baseURL,{UserName,Password}).pipe(map(resp=>{
      console.log(`token ${resp}`);
      sessionStorage.setItem("userDtls",UserName+":"+Password);
      sessionStorage.setItem("jwtString",'Bearer' +resp.jwt);
      return resp;
    }));
  }
  isUserLoggedIn(): boolean {
    let flag = true;
    if (sessionStorage.getItem("userDtls") === null)
      flag = false;
    console.log(`flag=${flag}`);
    return flag;
  }
  logout(): void {
    sessionStorage.removeItem("userDtls");
    sessionStorage.removeItem("jwtString");
  }

}
/*
export class AuthServiceService {
  baseURL = 'http://localhost:8080/authenticate';
  constructor(private http: HttpClient) { }
  //add member function for authentication
  authenticate(userName: string, password: string) {
     return this.http.post<any>(this.baseURL,{userName,password}).pipe(map(resp => {
      console.log(`token ${resp}`);
      sessionStorage.setItem("userDtls", userName + ":" + password);
      sessionStorage.setItem("jwtString", 'Bearer ' +resp.jwt);
      return resp;
    }));
  }
  isUserLoggedIn(): boolean {
    let flag = true;
    if (sessionStorage.getItem("userDtls") === null)
      flag = false;
    console.log(`flag=${flag}`);
    return flag;
  }
  logout(): void {
    sessionStorage.removeItem("userDtls");
    sessionStorage.removeItem("jwtString");
  }
}*/