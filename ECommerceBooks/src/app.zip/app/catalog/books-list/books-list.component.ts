import { Component, OnInit } from '@angular/core';
import { BooksHubService } from '../books-hub.service';
import{Books} from '../Book.module';
@Component({
  selector: 'app-books-list',
  templateUrl: './books-list.component.html',
  styleUrls: ['./books-list.component.css']
})
export class BooksListComponent implements OnInit {

  data:Books[];
  
  constructor(private svc:BooksHubService) { }

  ngOnInit():void {
      
    this.svc.getAllBooks().subscribe(
      (books:any) =>
      {
         this.data=books;
         //console.log(this.data); 
      },
      error=>
      {
        console.log(error);
      });
  }  

}
