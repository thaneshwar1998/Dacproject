import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { BookDetailsComponent } from './book-details/book-details.component';
import { BooksListComponent } from './books-list/books-list.component';
import { FormsModule } from '@angular/forms';
import { AuthenticationModule } from '../authentication/authentication.module';
import { LoginComponent } from '../authentication/login/login.component';
import { RegisterComponent } from '../authentication/register/register.component';
import { InsertComponent } from './insert/insert.component';



@NgModule({
  declarations: [
                  BookDetailsComponent, 
                  BooksListComponent,
                  InsertComponent
                ],
  imports: [
            CommonModule,
            FormsModule,
            AuthenticationModule,
            HttpClientModule
            ],
  exports:[
            BookDetailsComponent,
            BooksListComponent,
            InsertComponent
          ]
})
export class CatalogModule { }
