import { Component, OnInit ,Input} from '@angular/core';

@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit {
  @Input() id:number;
  @Input() title:string;
  @Input() author:string;
  @Input() description:string;
  @Input() price:Number;
  @Input() quantity:Number;
  @Input() imageUrl:string;
  
 
   constructor() { }  // used for Dependency Injection
 
   //component life cycle  Events (hook methods)
 
   ngOnInit(): void {
     
 
   }
   ngOnDestroy():void{
 
   }
 

}
