import { Component, OnInit } from '@angular/core';
import { FormBuilder ,Validators} from '@angular/forms';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { Books } from '../Book.module';
import{BooksHubService} from'../books-hub.service';
@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent implements OnInit 
{

  /*dataSaved = false;  
  bookForm: any;  
  allBooks: Observable<Books[]>;  
  BookIdUpdate = null;  
  massage = null;  */
  book=new Books();
  constructor(private svc:BooksHubService,private formbuilder:FormBuilder,
              private router:Router) { }

  ngOnInit(): void {
    /*this.bookForm=this.formbuilder.group({
      Title: ['', [Validators.required]],  
      Author: ['', [Validators.required]],  
      Description: ['', [Validators.required]],  
      ImageUrl: ['', [Validators.required]],  
      Price: ['', [Validators.required]],  
      Quantity: ['', [Validators.required]],  
    });*/
    
  }

  insert()
  {
    //console.log(this.book);
    this.svc.insertBook(this.book).subscribe(
      (Response)=>
      {
      console.log(Response);
      this.router.navigate(['/books']);
      });
  }
  /*onFormSubmit() {  
    this.dataSaved = false;  
    const book = this.bookForm.value;  
    this.insertBook(book);  
    this.bookForm.reset();  
  }

  insertBook(book: Books) {  
    if (this.BookIdUpdate == null) {  
      this.svc.insertBook(book).subscribe(  
        () => {  
          this.dataSaved = true;  
          this.massage = 'Record saved Successfully';  
          //this.loadAllEmployees();  
          this.BookIdUpdate = null;  
          this.bookForm.reset();  
        }  
      );  
    }
  }*/
}
    



      




