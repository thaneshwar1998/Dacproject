import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { CatalogModule } from './catalog/catalog.module';
import {BooksHubService} from './catalog/books-hub.service';
import {AuthenticationModule} from './authentication/authentication.module';
import { SPAModule } from './spa/spa.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    CatalogModule,
    ReactiveFormsModule,
    FormsModule,
    AuthenticationModule,
    HttpClientModule,
    SPAModule,
    
  ],
  providers: [BooksHubService],
  bootstrap: [AppComponent]
})
export class AppModule { }
