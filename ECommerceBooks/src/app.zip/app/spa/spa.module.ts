import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,RouterModule} from '@angular/router';
import { CatalogModule } from '../catalog/catalog.module';
import { StandardModule } from '../standard/standard.module';
import { ContainerComponent } from './container/container.component';
import { HomeComponent } from '../standard/home/home.component';
import { AboutusComponent } from '../standard/aboutus/aboutus.component';
import { ContactusComponent } from '../standard/contactus/contactus.component';
import { ServicesComponent } from '../standard/services/services.component';
import{BooksListComponent} from '../catalog/books-list/books-list.component';
import { LoginComponent } from '../authentication/login/login.component';
import { RegisterComponent } from '../authentication/register/register.component';
import {InsertComponent} from '../catalog/insert/insert.component';
const routes:Routes=
[
  {path:'',redirectTo:'books',pathMatch:'full'},
  {path:'home',component:HomeComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'contactus',component:ContactusComponent},
  {path:'service',component:ServicesComponent},
  {path:'books',component:BooksListComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'insert',component:InsertComponent}
  /*{path:'update/:id',component:InsertComponent},
  {path:'delete/:id',component:InsertComponent}*/
  
];


@NgModule({
  declarations: [ContainerComponent],
  imports: [
    CommonModule,
    CatalogModule,
    StandardModule,
    RouterModule.forRoot(routes)
  ],
  exports:[
    ContainerComponent
  ]
})
export class SPAModule { }
